package com.bank.enums;

public enum UserRole {
    SUPER_ADMIN,
    ADMIN,
    USER,
    PUBLIC
}
